Eat What? - interactive prototype of your Figma design (11 screens)

Run: double-click index.html, or in this folder run:  python3 -m http.server 8000  and open http://localhost:8000
Needs internet only for the Baloo 2 / Nunito Google Fonts. All art (logo, blobs, emoji) is in assets/.
